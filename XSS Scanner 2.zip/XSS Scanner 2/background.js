let isScanning = false;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length > 0) {
            const tabId = tabs[0].id;

            if (request.action === "start" && !isScanning) {
                isScanning = true;
                chrome.scripting.executeScript({
                    target: { tabId: tabId },
                    func: () => {
                        window.windowStopScanning = false; // Ensure scanning flag is reset
                        if (typeof window.startScanning === "function") {
                            window.startScanning(); // Trigger payload injection
                        }
                    }
                });
            } else if (request.action === "stop" && isScanning) {
                isScanning = false;
                chrome.scripting.executeScript({
                    target: { tabId: tabId },
                    func: () => {
                        if (typeof window.stopScanning === "function") {
                            window.stopScanning(); // Stop payload injection
                        }
                    }
                });
            }
        }
    });
});
