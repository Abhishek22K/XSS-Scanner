from flask import Flask, request, jsonify
import logging

app = Flask(__name__)

# Enable logging for debugging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')

# Common XSS payloads
XSS_PAYLOADS = [
    "<script>alert('XSS')</script>",
    "' onerror='alert(1)'",
    "<img src=x onerror=alert(1)>"
]

@app.route('/analyze', methods=['POST'])
def analyze():
    try:
        # Get the response from the request
        data = request.json
        response_content = data.get('response', '')

        logging.info("Analyzing response content...")
        logging.info(f"Response content received: {response_content[:200]}...")  # Log the first 200 characters

        # Check if any payload is reflected in the response
        for payload in XSS_PAYLOADS:
            if payload in response_content:
                logging.info(f"XSS vulnerability detected with payload: {payload}")
                return jsonify({"vulnerable": True, "payload": payload})

        logging.info("No XSS vulnerability detected.")
        return jsonify({"vulnerable": False})

    except Exception as e:
        logging.error(f"Error analyzing response: {str(e)}")
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
