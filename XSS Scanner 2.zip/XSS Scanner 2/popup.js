document.getElementById("start-scan").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "start" });
});

document.getElementById("stop-scan").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "stop" });
});
